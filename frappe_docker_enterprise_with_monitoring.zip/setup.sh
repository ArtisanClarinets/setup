#!/bin/bash

set -e

echo ">>> Building Docker image..."
docker buildx bake --load

echo ">>> Starting production services..."
docker compose -f docker-compose.prod.yml up -d

echo ">>> Waiting for backend container to be ready..."
sleep 20

echo ">>> Creating Frappe site and installing all apps..."
docker compose exec backend bench new-site artisanclarinets-erp.com \
  --mariadb-root-password admin! \
  --admin-password admin \
  --install-app erpnext \
  --install-app crm \
  --install-app hrms \
  --install-app lending \
  --install-app helpdesk \
  --install-app webshop \
  --install-app payments \
  --install-app ecommerce_integrations \
  --install-app shopify \
  --install-app repair \
  --install-app insights \
  --install-app wiki \
  --install-app builder

echo ">>> Requesting HTTPS certificate with Certbot..."
docker run --rm -v certbot-etc:/etc/letsencrypt -v certbot-var:/var/www/certbot \
  certbot/certbot certonly --webroot -w /var/www/certbot \
  --email admin@artisanclarinets-erp.com --agree-tos --no-eff-email \
  -d artisanclarinets-erp.com

echo ">>> Reloading NGINX with new certificates..."
docker compose restart nginx

echo ">>> All done. Access your site at: https://artisanclarinets-erp.com"